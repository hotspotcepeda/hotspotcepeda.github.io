---
title: "First"
date: 2019-10-30T19:45:20+09:00
description: "My first presentation"
tags:
-
series:
-
categories:
-
image: images/feature1/number-one.png
revealBackgroundColor: "" # #fff or rgba() or hsl()
revealBackgroundImage: "" # /images/myImage.png   <= static folder path
revealBackgroundPosition: "" # left top, left center, left bottom, right top, right center ...
revealBackgroundRepeat: "" # repeat, repeat-x, repeat-y, no-repeat, inherit
revealBackgroundOpacity: "" # 0~1
revealBackgroundVideo: "" # /videos/myVideo.mp4 <= static folder path, A single video source, or a comma separated list of video sources.
revealBackgroundVideoLoop: false # true, false
revealBackgroundVideoMuted: false # true, false
revealBackgroundSize: "" # cover, contain, ...
reveal: 
  - main:
    - sub: 
      - |
        test 1
  - main:
    - sub: 
      - |
        test 2
---
