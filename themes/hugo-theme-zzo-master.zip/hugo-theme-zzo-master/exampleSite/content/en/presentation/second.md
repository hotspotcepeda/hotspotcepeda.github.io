---
title: "Second"
date: 2019-10-30T20:45:24+09:00
description: "My second presentation"
tags:
-
series:
-
categories:
-
image: images/feature1/number-two.png
revealBackgroundColor: "" # #fff or rgba() or hsl()
revealBackgroundImage: "" # /images/myImage.png   <= static folder path
revealBackgroundPosition: "" # left top, left center, left bottom, right top, right center ...
revealBackgroundRepeat: "" # repeat, repeat-x, repeat-y, no-repeat, inherit
revealBackgroundOpacity: "" # 0~1
revealBackgroundVideo: "" # /videos/myVideo.mp4 <= static folder path, A single video source, or a comma separated list of video sources.
revealBackgroundVideoLoop: false # true, false
revealBackgroundVideoMuted: false # true, false
revealBackgroundSize: "" # cover, contain, ...
reveal: 
  - main:
    - sub: 
      - |
        test 1
  - main:
    - sub: 
      - |
        test 2
---
